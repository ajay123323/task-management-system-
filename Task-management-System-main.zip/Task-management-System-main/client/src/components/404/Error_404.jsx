import React from 'react'

function Error_404() {
    return (
      <div style={{ width: "100%" }}>
        <center>
          <img style={{ height:'600px' }} alt="404" src="/images/404.png" />
        </center>
      </div>
    );
}

export default Error_404
