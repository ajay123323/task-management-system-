const EditTask = () => {
	return <div>EditTask</div>;
};

export default EditTask;
